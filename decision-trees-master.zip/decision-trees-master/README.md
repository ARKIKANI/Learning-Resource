# decision-trees
Important things done here:

1. Visualizing a decision tree
2. Using GridsearchCV to find the best hyperparameters
